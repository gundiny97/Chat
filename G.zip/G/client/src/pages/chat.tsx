import { useState, useRef, useEffect } from 'react';
import { useSecureWebSocket } from '@/hooks/use-secure-websocket';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Shield, Lock, Eye, EyeOff } from 'lucide-react';

export default function Chat() {
  const [messageInput, setMessageInput] = useState('');
  const [showSessionId, setShowSessionId] = useState(false);
  const { isConnected, isSecure, connectionStatus, sendSecureMessage, messages, sessionId } = useSecureWebSocket();
  const chatMessagesRef = useRef<HTMLDivElement>(null);

  const handleSendMessage = async () => {
    if (messageInput.trim() && isConnected && isSecure) {
      await sendSecureMessage(messageInput.trim());
      setMessageInput('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (chatMessagesRef.current) {
      chatMessagesRef.current.scrollTop = chatMessagesRef.current.scrollHeight;
    }
  }, [messages]);

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'secure': return 'bg-green-500';
      case 'connected': return 'bg-yellow-500';
      case 'connecting': return 'bg-yellow-500 animate-pulse';
      case 'disconnected': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = () => {
    switch (connectionStatus) {
      case 'secure': return 'Seguro';
      case 'connected': return 'Conectado';
      case 'connecting': return 'Conectando...';
      case 'disconnected': return 'Desconectado';
      default: return 'Desconhecido';
    }
  };

  const getConnectionDetails = () => {
    switch (connectionStatus) {
      case 'secure': return 'Criptografia P-384 militar ativa';
      case 'connected': return 'Estabelecendo criptografia';
      case 'connecting': return 'Estabelecendo conexão segura';
      case 'disconnected': return 'Conexão perdida';
      default: return 'Status desconhecido';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 min-h-screen">
      {/* Header */}
      <header className="mb-6">
        <div className="bg-[hsl(240,3.7%,15.9%)] rounded-lg p-4 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h1 className="text-4xl font-bold text-white">
                G
              </h1>
              <p className="text-sm text-gray-400 mt-1">Mensagens privadas e seguras</p>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                {isSecure && <Lock className="w-4 h-4 text-green-400" />}
                <div className={`w-3 h-3 rounded-full ${getStatusColor()}`}></div>
                <span className="text-sm font-medium">{getStatusText()}</span>
              </div>
            </div>
          </div>
          

        </div>
      </header>

      {/* Chat Window */}
      <div className="bg-[hsl(240,3.7%,15.9%)] rounded-lg shadow-lg overflow-hidden">
        {/* Messages Area */}
        <div 
          ref={chatMessagesRef}
          className="h-[calc(100vh-280px)] min-h-[400px] overflow-y-auto p-4 space-y-3"
          style={{ scrollbarWidth: 'thin' }}
        >
          {messages.map((message, index) => {
            if (message.type === 'system') {
              return (
                <div key={index} className="flex justify-center">
                  <div className="bg-[hsl(240,10%,3.9%)] px-4 py-2 rounded-full text-xs text-gray-400">
                    {message.text}
                  </div>
                </div>
              );
            }

            if (message.isUser) {
              return (
                <div key={index} className="flex justify-end">
                  <div className="max-w-xs lg:max-w-md">
                    <div className="bg-[hsl(207,90%,54%)] text-white rounded-lg px-4 py-2 shadow-sm">
                      <p>{message.text}</p>
                    </div>
                    <div className="flex items-center justify-end mt-1 space-x-1">
                      <span className="text-xs text-gray-500">Você</span>
                      <span className="text-xs text-gray-500">{message.timestamp}</span>
                    </div>
                  </div>
                </div>
              );
            } else {
              return (
                <div key={index} className="flex justify-start">
                  <div className="max-w-xs lg:max-w-md">
                    <div className="bg-[hsl(120,100%,70%)] text-black rounded-lg px-4 py-2 shadow-sm">
                      <p>{message.text}</p>
                    </div>
                    <div className="flex items-center justify-start mt-1 space-x-1">
                      <span className="text-xs text-gray-500">Parceiro</span>
                      <span className="text-xs text-gray-500">{message.timestamp}</span>
                    </div>
                  </div>
                </div>
              );
            }
          })}
        </div>

        {/* Input Area */}
        <div className="border-t border-[hsl(240,3.7%,15.9%)] p-4">
          <div className="flex space-x-3">
            <div className="flex-1">
              <Input
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Digite sua mensagem..."
                className="w-full bg-[hsl(240,10%,3.9%)] border-[hsl(240,3.7%,15.9%)] text-white placeholder-gray-400 focus:ring-2 focus:ring-[hsl(207,90%,54%)] focus:border-transparent"
                maxLength={500}
                disabled={!isConnected}
              />
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!isConnected || !isSecure || !messageInput.trim()}
              className={`${
                isSecure 
                  ? 'bg-green-600 hover:bg-green-700' 
                  : 'bg-gray-600'
              } disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-medium px-6 py-3 flex items-center gap-2`}
            >
              {isSecure ? <Lock className="w-4 h-4" /> : <Shield className="w-4 h-4" />}
              <Send className="w-5 h-5" />
            </Button>
          </div>
          
          {/* Status and Character Counter */}
          <div className="flex justify-between items-center mt-2">
            <div className="text-xs text-gray-500">
              {isSecure && <span className="text-green-400">🔒 Mensagens protegidas</span>}
            </div>
            <div className="text-xs text-gray-500">
              <span className={messageInput.length > 450 ? 'text-red-400' : messageInput.length > 400 ? 'text-yellow-400' : 'text-gray-500'}>
                {messageInput.length}
              </span>/500
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-6 text-center">
        <div className="text-xs text-gray-500">
          Mensagens privadas e seguras
        </div>
      </footer>
    </div>
  );
}
