import { useState, useRef, useCallback, useEffect } from 'react';

export interface WebSocketMessage {
  type: 'system' | 'peer' | 'error';
  message: string;
  timestamp?: string;
}

export interface UseWebSocketReturn {
  isConnected: boolean;
  connectionStatus: 'connecting' | 'connected' | 'disconnected';
  sendMessage: (message: string) => void;
  messages: Array<{ text: string; isUser: boolean; timestamp: string; type?: string }>;
}

export function useWebSocket(): UseWebSocketReturn {
  const [isConnected, setIsConnected] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');
  const [messages, setMessages] = useState<Array<{ text: string; isUser: boolean; timestamp: string; type?: string }>>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const connectingRef = useRef(false);

  const addMessage = useCallback((text: string, isUser: boolean, type?: string) => {
    const timestamp = new Date().toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    setMessages(prev => [...prev, { text, isUser, timestamp, type }]);
  }, []);

  const connect = useCallback(() => {
    // Prevent multiple simultaneous connections
    if (connectingRef.current || (wsRef.current && wsRef.current.readyState === WebSocket.CONNECTING)) {
      return;
    }

    // Close existing connection if any
    if (wsRef.current) {
      wsRef.current.close();
    }

    connectingRef.current = true;
    setConnectionStatus('connecting');
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/chat-ws`;
    
    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      connectingRef.current = false;
      setIsConnected(true);
      setConnectionStatus('connected');
      console.log('WebSocket connected successfully');
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = undefined;
      }
    };

    wsRef.current.onmessage = (event) => {
      try {
        const data: WebSocketMessage = JSON.parse(event.data);
        addMessage(data.message, false, data.type);
      } catch (error) {
        addMessage(event.data, false);
      }
    };

    wsRef.current.onclose = (event) => {
      connectingRef.current = false;
      console.log('WebSocket closed - Code:', event.code, 'Reason:', event.reason);
      setIsConnected(false);
      setConnectionStatus('disconnected');
      
      if (event.code === 1006) {
        addMessage('Conexão perdida inesperadamente', false, 'system');
      } else if (event.code !== 1000) {
        addMessage(`Conexão encerrada (${event.code})`, false, 'system');
      }
      
      // Enable reconnection after successful initial connection
      if (event.code !== 1000 && !reconnectTimeoutRef.current) {
        reconnectTimeoutRef.current = setTimeout(() => {
          reconnectTimeoutRef.current = undefined;
          if (!isConnected) {
            connect();
          }
        }, 3000);
      }
    };

    wsRef.current.onerror = (error) => {
      connectingRef.current = false;
      console.error('WebSocket error:', error);
      setConnectionStatus('disconnected');
    };
  }, [addMessage, isConnected]);

  const sendMessage = useCallback((message: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && message.trim()) {
      try {
        wsRef.current.send(message);
        addMessage(message, true);
      } catch (error) {
        console.error('Failed to send message:', error);
        addMessage('Erro ao enviar mensagem', false, 'system');
      }
    }
  }, [addMessage]);

  useEffect(() => {
    let mounted = true;
    
    const initConnection = () => {
      if (mounted && !wsRef.current) {
        connect();
      }
    };

    // Delay initial connection to avoid React strict mode double mounting
    const timer = setTimeout(initConnection, 100);

    return () => {
      mounted = false;
      clearTimeout(timer);
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      
      if (wsRef.current) {
        wsRef.current.close(1000, 'Component unmounting');
      }
    };
  }, [connect]);

  return {
    isConnected,
    connectionStatus,
    sendMessage,
    messages
  };
}
