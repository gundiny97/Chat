import { useState, useRef, useCallback, useEffect } from "react";
import { SecureChat } from "@shared/crypto";

export interface SecureWebSocketMessage {
  type: "key-exchange" | "encrypted-message" | "system" | "error";
  data?: string;
  publicKey?: string;
  encryptedKey?: string;
  encrypted?: string;
  iv?: string;
  sessionId?: string;
}

export interface UseSecureWebSocketReturn {
  isConnected: boolean;
  isSecure: boolean;
  connectionStatus: "connecting" | "connected" | "secure" | "disconnected";
  sendSecureMessage: (message: string) => Promise<void>;
  messages: Array<{
    text: string;
    isUser: boolean;
    timestamp: string;
    type?: string;
  }>;
  sessionId: string;
}

export function useSecureWebSocket(): UseSecureWebSocketReturn {
  const [isConnected, setIsConnected] = useState(false);
  const [isSecure, setIsSecure] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<
    "connecting" | "connected" | "secure" | "disconnected"
  >("disconnected");
  const [messages, setMessages] = useState<
    Array<{ text: string; isUser: boolean; timestamp: string; type?: string }>
  >([]);
  const [sessionId] = useState(() => SecureChat.generateSessionId());

  const wsRef = useRef<WebSocket | null>(null);
  const keyPairRef = useRef<CryptoKeyPair | null>(null);
  const aesKeyRef = useRef<CryptoKey | null>(null);
  const peerPublicKeyRef = useRef<CryptoKey | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const connectingRef = useRef(false);

  const addMessage = useCallback(
    (text: string, isUser: boolean, type?: string) => {
      const timestamp = new Date().toLocaleTimeString("pt-BR", {
        hour: "2-digit",
        minute: "2-digit",
      });
      setMessages((prev) => [...prev, { text, isUser, timestamp, type }]);
    },
    [],
  );

  const initializeCrypto = useCallback(async () => {
    try {
      // Generate RSA key pair for key exchange
      keyPairRef.current = await SecureChat.generateKeyPair();

      // Generate symmetric key for message encryption
      aesKeyRef.current = await SecureChat.generateSymmetricKey();

      console.log("🔐 Cryptographic keys generated");
      return true;
    } catch (error) {
      console.error("Failed to initialize crypto:", error);
      addMessage("❌ Falha na inicialização criptográfica", false, "system");
      return false;
    }
  }, [addMessage]);

  const handleKeyExchange = useCallback(
    async (message: SecureWebSocketMessage) => {
      try {
        if (!keyPairRef.current || !aesKeyRef.current) return;

        if (message.publicKey && !peerPublicKeyRef.current) {
          // Received peer's public key, send our key and encrypted AES key
          peerPublicKeyRef.current = await SecureChat.importPublicKey(
            message.publicKey,
          );

          const ourPublicKey = await SecureChat.exportPublicKey(
            keyPairRef.current.publicKey,
          );
          // For ECDH, we derive the shared secret instead of encrypting keys
          aesKeyRef.current = await SecureChat.deriveSharedSecret(
            keyPairRef.current.privateKey,
            peerPublicKeyRef.current,
          );

          if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(
              JSON.stringify({
                type: "key-exchange",
                publicKey: ourPublicKey,
                sessionId: sessionId,
              }),
            );
          }

          setIsSecure(true);
          setConnectionStatus("secure");
          addMessage(
            "🔒 Criptografia P-384 estabelecida - Máxima segurança ativa",
            false,
            "system",
          );
        }
      } catch (error) {
        console.error("Key exchange failed:", error);
        addMessage("❌ Falha na troca de chaves", false, "system");
      }
    },
    [addMessage, sessionId],
  );

  const handleEncryptedMessage = useCallback(
    async (message: SecureWebSocketMessage) => {
      try {
        if (!aesKeyRef.current || !message.encrypted || !message.iv) return;

        const decryptedMessage = await SecureChat.decryptMessage(
          message.encrypted,
          message.iv,
          aesKeyRef.current,
          sessionId,
        );

        addMessage(decryptedMessage, false);
      } catch (error) {
        console.error("Failed to decrypt message:", error);
        addMessage("❌ Falha ao descriptografar mensagem", false, "system");
      }
    },
    [addMessage],
  );

  const connect = useCallback(async () => {
    // Prevent multiple simultaneous connections
    if (connectingRef.current || (wsRef.current && wsRef.current.readyState <= WebSocket.OPEN)) {
      console.log('⚠️ Connection already exists or in progress');
      return;
    }

    // Clean up any existing connection
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    // Initialize cryptographic keys
    const cryptoReady = await initializeCrypto();
    if (!cryptoReady) {
      console.error('❌ Crypto initialization failed');
      return;
    }

    connectingRef.current = true;
    setConnectionStatus("connecting");

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/chat-ws`;
    console.log('🔌 Connecting to:', wsUrl);

    try {
      wsRef.current = new WebSocket(wsUrl);
    } catch (error) {
      console.error('❌ Failed to create WebSocket:', error);
      connectingRef.current = false;
      setConnectionStatus("disconnected");
      return;
    }

    wsRef.current.onopen = async () => {
      console.log('✅ WebSocket connected successfully');
      connectingRef.current = false;
      setIsConnected(true);
      setConnectionStatus("connected");

      // Start key exchange after successful connection
      try {
        if (keyPairRef.current) {
          const publicKey = await SecureChat.exportPublicKey(keyPairRef.current.publicKey);
          
          if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({
              type: "key-exchange",
              publicKey: publicKey,
              sessionId: sessionId,
            }));
            console.log('🔑 Key exchange initiated');
          }
        }
      } catch (error) {
        console.error('❌ Key exchange failed:', error);
      }

      addMessage("🔐 Conectado - Estabelecendo criptografia militar...", false, "system");

      // Clear any pending reconnection attempts
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = undefined;
      }
    };

    wsRef.current.onmessage = async (event) => {
      try {
        const message: SecureWebSocketMessage = JSON.parse(event.data);

        switch (message.type) {
          case "key-exchange":
            await handleKeyExchange(message);
            break;
          case "encrypted-message":
            await handleEncryptedMessage(message);
            break;
          case "system":
            if (message.data) {
              addMessage(message.data, false, "system");
            }
            break;
          case "error":
            if (message.data) {
              addMessage(message.data, false, "system");
            }
            break;
        }
      } catch (error) {
        console.error("Failed to process message:", error);
      }
    };

    wsRef.current.onclose = (event) => {
      connectingRef.current = false;
      setIsConnected(false);
      setIsSecure(false);
      setConnectionStatus("disconnected");
      peerPublicKeyRef.current = null;

      if (event.code === 1006) {
        addMessage("🔴 Conexão perdida inesperadamente", false, "system");
      } else if (event.code !== 1000) {
        addMessage(`🔴 Conexão encerrada (${event.code})`, false, "system");
      }

      if (event.code !== 1000 && !reconnectTimeoutRef.current) {
        addMessage("🔄 Reconectando em 3 segundos...", false, "system");
        reconnectTimeoutRef.current = setTimeout(() => {
          reconnectTimeoutRef.current = undefined;
          if (!isConnected) {
            connect();
          }
        }, 3000);
      }
    };

    wsRef.current.onerror = (error) => {
      connectingRef.current = false;
      console.error("🚨 WebSocket error:", error);
      setConnectionStatus("disconnected");
      addMessage("❌ Erro de conexão - verificando conectividade...", false, "system");
    };
  }, [
    initializeCrypto,
    handleKeyExchange,
    handleEncryptedMessage,
    addMessage,
    sessionId,
    isConnected,
  ]);

  const sendSecureMessage = useCallback(
    async (message: string) => {
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
        addMessage("❌ Conexão não disponível", false, "system");
        return;
      }

      if (!isSecure || !aesKeyRef.current) {
        addMessage("❌ Criptografia não estabelecida", false, "system");
        return;
      }

      try {
        const { encrypted, iv } = await SecureChat.encryptMessage(
          message,
          aesKeyRef.current,
          sessionId,
        );

        wsRef.current.send(
          JSON.stringify({
            type: "encrypted-message",
            encrypted: encrypted,
            iv: iv,
            sessionId: sessionId,
          }),
        );

        addMessage(message, true);
      } catch (error) {
        console.error("Failed to send encrypted message:", error);
        addMessage("❌ Falha ao enviar mensagem segura", false, "system");
      }
    },
    [isSecure, addMessage, sessionId],
  );

  useEffect(() => {
    // Connect once on mount
    connect();

    return () => {
      // Clean up on unmount
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = undefined;
      }
      if (wsRef.current && wsRef.current.readyState <= WebSocket.OPEN) {
        wsRef.current.close(1000, "Component unmounting");
      }
    };
  }, []); // Empty dependency array to run only on mount/unmount

  return {
    isConnected,
    isSecure,
    connectionStatus,
    sendSecureMessage,
    messages,
    sessionId,
  };
}
