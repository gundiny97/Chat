import { WebSocketServer, WebSocket } from "ws";
import { type Server } from "http";
import { storage } from "./storage";

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ 
    server,
    path: '/chat-ws'
  });

  console.log('WebSocket server created on path /chat-ws');

  wss.on('connection', (ws: WebSocket, req) => {
    console.log('New WebSocket client connected');

    // Keep the connection alive
    const heartbeat = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.ping();
      }
    }, 30000);

    ws.on('pong', () => {
      console.log('Received pong from client');
    });

    // Send welcome message
    setTimeout(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'system',
          message: 'Conectado ao servidor!'
        }));
      }
    }, 100);

    ws.on('message', async (data) => {
      try {
        const messageStr = data.toString();
        const message = JSON.parse(messageStr);
        
        console.log('Received secure message type:', message.type);

        switch (message.type) {
          case 'key-exchange':
            // Forward key exchange messages to other clients (no server storage)
            console.log('🔑 Forwarding key exchange');
            wss.clients.forEach((client) => {
              if (client !== ws && client.readyState === WebSocket.OPEN) {
                client.send(messageStr);
              }
            });
            break;

          case 'encrypted-message':
            // Forward encrypted messages without decryption (zero-knowledge server)
            console.log('🔐 Forwarding encrypted message');
            wss.clients.forEach((client) => {
              if (client !== ws && client.readyState === WebSocket.OPEN) {
                client.send(messageStr);
              }
            });
            break;

          default:
            // Block plain text messages for security
            console.log('🚫 Blocked plain text message for security');
            
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({
                type: 'error',
                data: '🚫 Apenas mensagens criptografadas são permitidas'
              }));
            }
            break;
        }

      } catch (error) {
        console.error('Message processing error:', error);
        
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'error',
            data: 'Erro no processamento da mensagem'
          }));
        }
      }
    });

    ws.on('close', (code, reason) => {
      console.log(`WebSocket closed: ${code} - ${reason}`);
      clearInterval(heartbeat);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clearInterval(heartbeat);
    });
  });

  return wss;
}